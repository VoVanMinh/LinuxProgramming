<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Strict//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-strict.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="content-type" content="text/html; charset=utf-8" />
<title>Lập trình Hướng đối tượng</title>
<meta name="keywords" content="Điện hoa Thuỳ Phương" />
<meta name="Premium Series" content="Điện hoa Thuỳ Phương" />
<link href="css/default.css" rel="stylesheet" type="text/css" media="screen" />
</head>
<body>
<?php
// Kiểm tra giá trị nhập


?>
<form id="searchform" method="post" action="#">
  <div id="sidebar1" class="sidebar">
    <h2>Tìm hoa</h2>
    <input type="text" name="txtSearch" id="txtSearch" size="28" value="" placeholder="Nhập giá trị tìm " /><input type="image" src="images/icon_search.gif" name="btnTim" />
  </div>
</form>
  


</body>
</html>
