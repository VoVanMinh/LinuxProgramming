<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Strict//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-strict.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="content-type" content="text/html; charset=utf-8" />
<title>Lập trình Hướng đối tượng</title>
<meta name="keywords" content="Điện hoa Thuỳ Phương" />
<meta name="Premium Series" content="Điện hoa Thuỳ Phương" />
<link href="css/default.css" rel="stylesheet" type="text/css" media="screen" />
</head>
<body>
<?php
// Kiểm tra giá trị nhập


?>
<form id="searchform" method="post" action="#">
  <div id="sidebar1" class="sidebar">
    <h2>Đăng ký Nhận tin</h2>
    <table border="0">
  <tr>
    <td>Họ tên</td>
    <td><input type="text" name="txtHoten" id="txtHoten" size="25" value="" placeholder="Nhập Họ tên " /></td>
  </tr>
  <tr>
    <td>Email</td>
    <td><input type="text" name="txtEmail" id="txtEmail" size="25" value="" placeholder="Nhập Email " /></td>
  </tr>
  <tr>
    <td>Nhập Code</td>
    <td><input type="text" name="txtCode" id="txtCode" size="15" value="" placeholder="Nhập Code " /><img src="images/fake_captcha.png" width="" height="18px"  />  </td>
  </tr>
  <tr align="center">
    <td colspan="2">
    <input type="submit" value="Gửi" name="btnGui" class="register" />
    </td>
  </tr>
</table>
    
  </div>
</form>
  


</body>
</html>
