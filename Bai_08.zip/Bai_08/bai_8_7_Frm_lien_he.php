<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Strict//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-strict.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="content-type" content="text/html; charset=utf-8" />
<title>Điện hoa Thuỳ Phương</title>
<meta name="keywords" content="Điện hoa Thuỳ Phương" />
<meta name="Premium Series" content="Điện hoa Thuỳ Phương" />
<link href="css/default.css" rel="stylesheet" type="text/css" media="screen" />
<link href="css/upload.css" rel="stylesheet" type="text/css">
</head>
<?php
// Khai báo thư viện: library/XL_Tap_tin.php,library/XL_Mang.php 
// Khai báo các biến lưu trữ
// Kiểm tra thông tin hợp lệ lưu vào tập tin files/Lien_he.txt
?>
<body>
<div class="post" style="width:600px"  >
  <h2 class="title"><a href="#">LIÊN HỆ </a></h2>
  <p class="byline"><small>&nbsp;</small></p>
  <div class="news">
  <form method="post" name="frm_lien_he">
    <div class="contact_form">
      <div class="form_subtitle">Nhập thông tin</div>
      <div class="form_row">
        <label class="contact"><strong>Họ tên:</strong></label>
        <input type="text" class="contact_input" name="txtHoten" />
      </div>
      <div class="form_row">
        <label class="contact"><strong>Email:</strong></label>
        <input type="text" class="contact_input" name="txtEmail" />
      </div>
      <div class="form_row">
        <label class="contact"><strong>Điện thoại:</strong></label>
        <input type="text" class="contact_input" name="txtDienthoai" />
      </div>
      <div class="form_row">
        <label class="contact"><strong>Tiêu đề:</strong></label>
        <input type="text" class="contact_input" name="txtTieude" />
      </div>
      <div class="form_row">
        <label class="contact"><strong>Nội dung:</strong></label>
        <textarea class="contact_textarea" name="txtNoidung" ></textarea>
      </div>
      <div class="form_row">
      
      <input type="submit" value="Gửi" name="btnGui" class="contact" />
      </div>
    </div>
    </form>
  </div>
</div>
</body>
</html>
