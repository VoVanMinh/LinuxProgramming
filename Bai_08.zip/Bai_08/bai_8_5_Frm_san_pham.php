<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Strict//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-strict.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="content-type" content="text/html; charset=utf-8" />
<title>Điện hoa Thuỳ Phương</title>
<meta name="keywords" content="Điện hoa Thuỳ Phương" />
<meta name="Premium Series" content="Điện hoa Thuỳ Phương" />
<link href="css/default.css" rel="stylesheet" type="text/css" media="screen" />
<link href="css/upload.css" rel="stylesheet" type="text/css">
</head>
<body>
<?php
include("library/XL_Tap_tin.php");
include("library/XL_Mang.php");
// Đọc chủ đề
$path="files/Tang_hoa_theo_chu_de.txt";
$Data_str=Doc_tap_tin($path);
$arr=Tach_chuoi_thanh_mang("/*",$Data_str);
$arr=array_slice($arr,1);

// Khai báo thư viện: library/XL_Tap_tin.php,library/XL_Mang.php 
// Khai báo các biến lưu trữ
// Kiểm tra thông tin hợp lệ lưu vào tập tin files/hoa.txt
?>
<div class="post" style="width:600px">
  <h2 class="title"><a href="#">CẬP NHẬT SẢN PHẨM </a></h2>
  <p class="byline"><small>&nbsp;</small></p>
    
	<form action="" method="post" name="frm_San_pham" enctype="multipart/form-data">
    <table width="100%" border="0" cellspacing="5" cellpadding="5">
      <tr>
        <td><label>Tên sản phẩm:</label></td>
        <td>
        	<input type="text" name="txtTensp" placeholder="Nhập Tên sản phẩm" value="" size="50" /> 
        </td>
      </tr>
      <tr>
        <td><label>Đơn giá:</label></td>
        <td><input type="text" name="txtDongia" placeholder="Nhập đơn giá"  value="" /> VNĐ</td>
      </tr>
      <tr>
        <td><label>Loại sản phẩm:</label></td>
        <td><select name="mnuLoai">
                <?php
                foreach($arr as $row)
				  {
					  $r=Tach_chuoi_thanh_mang("|",$row);
					  $id=$r[0];
					  $tenCD=$r[1];
				?>
                <option value="<?php echo $id ?>"><?php echo $tenCD ?></option>
                <?php
				  }
				?>
            </select>
         </td>
      </tr>
      <tr>
        <td><label>Mô tả:</label></td>
        <td><textarea name="txtMota" cols="50" rows="5" placeholder="Nhập thông tin mô tả"></textarea></td>
      </tr>
      <tr>
        <td><label>Sản phẩm tiêu biểu:</label></td>
        <td><input type="checkbox" name="chk" /></td>
      </tr>
      <tr>
        <td colspan="2">
        <fieldset>
            <legend>Hình sản phẩm</legend>
            <input type="file" name="f_hv" />
		</fieldset>
        </td>
      </tr>
      <tr>
        <td colspan="2" align="center"><input type="submit" name="btnLuu" value="Lưu Sản phẩm" /></td>
      </tr>
      <tr>
        <td colspan="2" align="center" style="color:#F00; font-style:italic">Thông báo</td>
      </tr>
    </table>
    </form>
    
</div>
</body>
</html>