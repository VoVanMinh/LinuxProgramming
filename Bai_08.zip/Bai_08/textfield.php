<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<title>Text Field</title>
</head>
<?php
$hoten=$matkhau=$ghichu="";
if(isset($_POST["submit"]))
{
	$hoten=$_POST["hoten"];
	$matkhau=$_POST["matkhau"];
	$ghichu=$_POST["ghichu"];
	
	echo "$hoten<br>$matkhau<br>";
	echo nl2br($ghichu);
}
?>
<body>
<form action="" method="post" name="frm">
<p>Nhập họ tên: <input type="text" name="hoten" size="50" maxlength="10"  placeholder="Nhập họ tên" value="<?php echo $hoten?>" /> </p>
<p>Nhập mật khẩu: <input type="password" name="matkhau" value="<?php echo $matkhau ?>" /> </p>
<p>Ghi chú: <textarea name="ghichu" rows="5" cols="30" ><?php echo $ghichu ?></textarea> </p>
<input type="submit" value="Đăng ký" name="submit" />

</form>
</body>
</html>