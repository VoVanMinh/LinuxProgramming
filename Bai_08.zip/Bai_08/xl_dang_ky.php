<?php
print_r($_POST);
echo "<hr>";
print_r($_FILES["file"])
?>