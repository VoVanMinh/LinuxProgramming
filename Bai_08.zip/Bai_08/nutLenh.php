<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<title>Nút Lệnh</title>
</head>
<?php
$hoten=$matkhau="";
if(isset($_POST))
{
	$hoten=$_POST["hoten"];
	$matkhau=$_POST["matkhau"];
	echo $hoten;
}
?>
<body>
<form action="" method="post" name="frm">
<p>Nhập họ tên: <input type="text" name="hoten" size="50" maxlength="10"  placeholder="Nhập họ tên" value="<?php echo $hoten?>" /> </p>
<p>Nhập mật khẩu: <input type="password" name="matkhau" value="<?php echo $matkhau ?>" /> </p>
<hr />
<input type="submit" value="submit" name="submit" /> |
<input type="reset" value="reset" name="reset" /> |
<input type="button" value="button" name="button" onclick="alert('Lập trình ở client')" /> |
<input type="image" value="images" name="image" src="images/cart.gif"  />

</form>
</body>
</html>