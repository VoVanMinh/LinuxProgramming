<?php
class Khach_hang
{
	// Khai báo biến thuộc tính
	
	// Khai báo phương thức khởi tạo
	
}
?>