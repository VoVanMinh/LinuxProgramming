<?php
class Hoa
{
	// Khai báo biến thuộc tính
	
	// Khai báo phương thức khởi tạo
		
}
?>