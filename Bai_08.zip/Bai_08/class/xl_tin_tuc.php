<?php
class Tin_tuc
{
	// Khai báo biến thuộc tính
	
	// Khai báo phương thức khởi tạo
	
}
?>