<?php
class Phep_tinh
{
	// Khai báo biến thuộc tính
	
	// Khai báo phương thức khởi tạo
	
	// Khai báo phương thức tính toán: Cộng trừ nhân chia
		
}
?>