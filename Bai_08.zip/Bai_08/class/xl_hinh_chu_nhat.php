<?php
class Hinh_chu_nhat
{
	// Khai báo biến thuộc tính
	
	// Khai báo phương thức khởi tạo
	
	// Khai báo phương thức tính toán
	
			
}
?>
