<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Strict//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-strict.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="content-type" content="text/html; charset=utf-8" />
<title>Điện hoa Thuỳ Phương</title>
<meta name="keywords" content="Điện hoa Thuỳ Phương" />
<meta name="Premium Series" content="Điện hoa Thuỳ Phương" />
<link href="css/default.css" rel="stylesheet" type="text/css" media="screen" />
<link href="css/upload.css" rel="stylesheet" type="text/css">
</head>
<body>
<?php
include("library/XL_Tap_tin.php");
include("library/XL_Mang.php");
$dir='images/';
$hinh=NULL; 
// Lấy nội dung thư mục đưa vào một mảng
$File_list = Duyet_thu_muc($dir);
// Chỉ upload file có kiểu
$valid_formats = array("jpg", "png", "gif", "zip", "bmp");
$max_file_size = 1024*100; //100 kb
$path = "images/"; // Upload directory
$count = 0;
if(isset($_POST) && $_SERVER['REQUEST_METHOD'] == "POST"){
	// Loop $_FILES to execute all files
	foreach ($_FILES['files']['name'] as $f => $name) {     
	    if ($_FILES['files']['error'][$f] == 4) {
	        continue; // Skip file if any error found
	    }	       
	    if ($_FILES['files']['error'][$f] == 0) {	           
	        if ($_FILES['files']['size'][$f] > $max_file_size) {
	            $message[] = "$name kích thước lớn hơn mức qui định!.";
	            continue; // Skip large files
	        }
			elseif(!in_array(pathinfo($name, PATHINFO_EXTENSION), $valid_formats) ){
				$message[] = "$name định dạng không hợp lệ";
				continue; // Skip invalid file formats
			}
	        else{ // No error found! Move uploaded files 
	            
				$tm=$_POST["mnu_Danh_sach_thu_muc"]."/";
				if(move_uploaded_file($_FILES["files"]["tmp_name"][$f], $path.$tm.$name)) {
	            	$count++; // Number of successfully uploaded files
	            }
	        }
	    }
	}
}
?>
<div class="post" style="width:500px">
  <h2 class="title"><a href="#">UPLOAD FILES </a></h2>
  <p class="byline"><small>&nbsp;</small></p>
<?php
if (isset($message)) {
			foreach ($message as $msg) {
				printf("<p class='status'>%s</p></ br>\n", $msg);
			}
		}
		# success message
		if($count !=0){
			printf("<p class='status'>%d files thành công!</p>\n", $count);
		}
?>
		<p>Max file size 100kb, Valid formats jpg, png, gif</p>
		<br />
		<br />
		<!-- Multiple file upload html form-->
		<form action="" method="post" enctype="multipart/form-data">
			<input type="file" name="files[]" multiple="multiple" accept="image/*" size="50">
            <p>
            Chọn thư mục upload:
            <select name="mnu_Danh_sach_thu_muc">
            <?php
            // Duyệt mảng xuất ra thể hiện
			foreach ($File_list as $file) 
			{
			    if (is_dir("$dir/$file") && $file != '.' && $file != '..') 
				{
            ?>
				<option><?php echo $file ?></option>
            <?php
				}
			}
			?>
            </select>&nbsp;&nbsp;<font color="#FF0000">(*)</font>
            </p>
			<p class="byline"><small>&nbsp;</small></p>
            <input type="submit" value="Upload">
		</form>	
        			
</div>
</body>
</html>