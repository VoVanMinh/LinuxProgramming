<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Strict//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-strict.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="content-type" content="text/html; charset=utf-8" />
<title>Điện hoa Thuỳ Phương</title>
<meta name="keywords" content="Điện hoa Thuỳ Phương" />
<meta name="Premium Series" content="Điện hoa Thuỳ Phương" />
<link href="css/default.css" rel="stylesheet" type="text/css" media="screen" />
<link href="css/upload.css" rel="stylesheet" type="text/css">
</head>
<body>
<?php
// Khai báo thư viện: library/XL_Tap_tin.php,library/XL_Mang.php 
// Khai báo các biến lưu trữ
// Kiểm tra thông tin hợp lệ lưu vào tập tin files/Tin_tuc.txt
?>
<div class="post" style="width:600px">
  <h2 class="title"><a href="#">CẬP NHẬT TIN TỨC SẢN PHẨM </a></h2>
  <p class="byline"><small>&nbsp;</small></p>
	<form action="" method="post" name="frm_Tin_tuc" enctype="multipart/form-data">
    <table width="100%" border="0" cellspacing="5" cellpadding="5">
      <tr>
        <td><label>Tiêu đề:</label></td>
        <td>
        	<input type="text" name="txtTieude" placeholder="Nhập tiêu đề" value="" size="50"/>
        </td>
      </tr>
      
      <tr>
        <td><label>Nội dung:</label></td>
        <td><textarea name="txtNoidung" cols="50" rows="5" placeholder="Nhập nội dung"></textarea></td>
      </tr>
      
      <tr>
        <td colspan="2">
        <fieldset>
            <legend>Hình Tin tức</legend>
            <input type="file" name="f_hv" />
		</fieldset>
        </td>
      </tr>
      <tr>
        <td colspan="2" align="center"><input type="submit" name="btnLuu" value="Lưu tin tức" /></td>
      </tr>
      <tr>
        <td colspan="2" align="center" style="color:#F00; font-style:italic">Thông báo</td>
      </tr>
    </table>
    </form>
</div>
</body>
</html>